"""Bcrypt hasher, session manager."""
